﻿using O2DESNet;
using System;

namespace SimulationChallenge2026
{
    internal class Model : Sandbox
    {
        public MaritimeDataContext DataContext { get; }

        // --- Generators ---
        public Shipment_Generator Shipment_Generator { get; }
        public Vessel_Generator Vessel_Generator { get; }
        public Berth_Generator Berth_Generator { get; }

        // --- Activities ---
        public Vessel_AwaitingInstructions Vessel_AwaitingInstructions { get; }
        //public Berth_Idle Berth_Idle { get; }
        //public Berth_Berthing Berth_Berthing { get; }
        //public Berth_HandlingCargo Berth_HandlingCargo { get; }

        public Model(MaritimeDataContext dataContext, int seed = 0)
            : base(seed: seed)
        {
            DataContext = dataContext
                ?? throw new ArgumentNullException(nameof(dataContext));

            // --- Generators ---
            Shipment_Generator = AddChild(
                new Shipment_Generator(DataContext, seed: DefaultRS.Next()) { EnableLog = false });

            Vessel_Generator = AddChild(
                new Vessel_Generator(DataContext, seed: DefaultRS.Next()) { EnableLog = false });

            Berth_Generator = AddChild(
                new Berth_Generator(DataContext, seed: DefaultRS.Next()) { EnableLog = false });

            // --- Activities ---
            Vessel_AwaitingInstructions = AddChild(
                new Vessel_AwaitingInstructions(seed: DefaultRS.Next()) { EnableLog = true });

            //Berth_Idle = AddChild(
            //    new Berth_Idle(seed: DefaultRS.Next()));

            //Berth_Berthing = AddChild(
            //    new Berth_Berthing(seed: DefaultRS.Next()));

            //Berth_HandlingCargo = AddChild(
            //    new Berth_HandlingCargo(seed: DefaultRS.Next()));

            // =========================================================
            // 🔗 Event Wiring (Core System Logic)
            // =========================================================

            // --- Vessel flow ---
            Vessel_Generator.OnArrive.Add(Vessel_AwaitingInstructions.RequestStart);

            // --- Berth flow ---
            //Berth_Generator.OnArrive.Add(Berth_Idle.RequestStart);

            //// --- Vessel → Sailing (next step placeholder) ---
            //// Vessel_AwaitingInstructions.OnFinish.Add(...)

            //// --- Berth lifecycle ---
            //Berth_Idle.OnFinish.Add(Berth_Berthing.RequestStart);
            //Berth_Berthing.OnFinish.Add(Berth_HandlingCargo.RequestStart);
            //Berth_HandlingCargo.OnFinish.Add(Berth_Idle.RequestStart);

        }
    }
}