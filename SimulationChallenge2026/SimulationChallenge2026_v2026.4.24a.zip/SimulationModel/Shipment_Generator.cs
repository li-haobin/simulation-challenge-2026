﻿using MathNet.Numerics.Distributions;
using O2DESNet;
using O2DESNet.Standard;
using System;
using System.Collections.Generic;
using System.Text;

namespace SimulationChallenge2026
{
    public class Shipment_Generator : Sandbox
    {
        public MaritimeDataContext MaritimeDataContext { get; }

        private int _nextShipmentIndex = 1;

        /// <summary>
        /// Mean number of shipments generated per demand per day.
        /// Default = 1 shipment/day.
        /// </summary>
        public double MeanShipmentsPerDay { get; }
        public bool EnableLog { get; set; } = true;

        public List<Action<Shipment>> OnArrive { get; } = new();

        public Shipment_Generator(
            MaritimeDataContext maritimeDataContext,
            double meanShipmentsPerDay = 1.0,
            int seed = 0) : base(id: nameof(Shipment_Generator), seed: seed)
        {
            MaritimeDataContext = maritimeDataContext ?? throw new ArgumentNullException(nameof(maritimeDataContext));

            if (meanShipmentsPerDay <= 0)
                throw new ArgumentOutOfRangeException(nameof(meanShipmentsPerDay), "Mean shipments per day must be positive.");

            MeanShipmentsPerDay = meanShipmentsPerDay;

            foreach (var demand in MaritimeDataContext.Demands)
            {
                Schedule(() => Arrive(demand), NextInterarrivalTime());
            }
        }

        private void Arrive(Demand demand)
        {
            if (demand == null) throw new ArgumentNullException(nameof(demand));

            double expectedTeuPerShipment = demand.AnnualTEUs / 365.0 / MeanShipmentsPerDay;

            int teuSize = SampleShipmentTeuSize(expectedTeuPerShipment);

            var shipment = new Shipment
            {
                Index = _nextShipmentIndex++,
                TeuSize = teuSize,
                Demand = demand,
                CurrentStoragePort = demand.OriginPort
            };

            demand.Shipments.Add(shipment);
            demand.OriginPort.ShipmentsInStorage.Add(shipment);

            Schedule(() => Arrive(demand), NextInterarrivalTime());

            if (EnableLog)
            {
                Console.WriteLine(
                    $"[{ClockTime:d\\.hh\\:mm\\:ss}] " +
                    $"Shipment {shipment.Index} arrived | " +
                    $"{shipment.TeuSize} TEU | " +
                    $"{demand.OriginPort.Name} -> {demand.DestinationPort.Name} | " +
                    $"Storage at {demand.OriginPort.Name}"
                );
            }

            foreach (var action in OnArrive) action?.Invoke(shipment);
        }

        private TimeSpan NextInterarrivalTime()
        {
            // Exponential.Sample(random, rate), where mean = 1 / rate
            double days = Exponential.Sample(DefaultRS, MeanShipmentsPerDay);
            return TimeSpan.FromDays(days);
        }

        private int SampleShipmentTeuSize(double expectedTeuPerShipment)
        {
            if (expectedTeuPerShipment <= 0)
                return 1;

            int sampled = Poisson.Sample(DefaultRS, expectedTeuPerShipment);

            // Avoid zero-size shipments
            return Math.Max(1, sampled);
        }
    }
}
