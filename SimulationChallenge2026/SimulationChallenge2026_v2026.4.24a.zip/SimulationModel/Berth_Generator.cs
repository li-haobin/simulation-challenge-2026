﻿using O2DESNet;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SimulationChallenge2026
{
    public class Berth_Generator : Sandbox
    {
        public MaritimeDataContext MaritimeDataContext { get; }

        public bool EnableLog { get; set; } = true;

        public List<Action<Berth>> OnArrive { get; } = new();

        public Berth_Generator(
            MaritimeDataContext maritimeDataContext,
            int seed = 0) : base(id: nameof(Berth_Generator), seed: seed)
        {
            MaritimeDataContext = maritimeDataContext
                ?? throw new ArgumentNullException(nameof(maritimeDataContext));

            foreach (var berth in MaritimeDataContext.Ports.SelectMany(p => p.Berths))
            {
                Schedule(() => Arrive(berth), TimeSpan.Zero);
            }
        }

        private void Arrive(Berth berth)
        {
            if (berth == null)
                throw new ArgumentNullException(nameof(berth));

            if (EnableLog)
            {
                Console.WriteLine(
                    $"[{ClockTime:d\\.hh\\:mm\\:ss}] " +
                    $"Berth arrived | " +
                    $"{berth.Port.Name} | " +
                    $"Berth {berth.Index}"
                );
            }

            foreach (var action in OnArrive) action?.Invoke(berth);
        }
    }
}