﻿using O2DESNet;
using System;
using System.Collections.Generic;

namespace SimulationChallenge2026
{
    public class Vessel_Generator : Sandbox
    {
        public MaritimeDataContext MaritimeDataContext { get; }

        public bool EnableLog { get; set; } = true;

        public List<Action<Vessel>> OnArrive { get; } = new();

        public Vessel_Generator(
            MaritimeDataContext maritimeDataContext,
            int seed = 0) : base(id: nameof(Vessel_Generator), seed: seed)
        {
            MaritimeDataContext = maritimeDataContext ?? throw new ArgumentNullException(nameof(maritimeDataContext));
            foreach (var vessel in MaritimeDataContext.Vessels)
                Schedule(() => Arrive(vessel), TimeSpan.Zero);
        }

        private void Arrive(Vessel vessel)
        {
            if (EnableLog)
            {
                Console.WriteLine(
                    $"[{ClockTime:d\\.hh\\:mm\\:ss}] " +
                    $"Vessel {vessel.Index} arrived | " +
                    $"{vessel.VesselClass.Name} | " +
                    $"Route {vessel.AssignedServiceRoute?.Id ?? "N/A"}"
                );
            }

            foreach (var action in OnArrive) action?.Invoke(vessel);
        }
    }
}